// 弹出窗口脚本

document.addEventListener('DOMContentLoaded', function() {
    const cleanBtn = document.getElementById('cleanBtn');
    const resultDiv = document.getElementById('result');
    const statsDiv = document.getElementById('stats');

    // 显示当前窗口统计
    updateWindowStats();

    // 清理按钮点击事件
    cleanBtn.addEventListener('click', async function() {
        cleanBtn.disabled = true;
        cleanBtn.textContent = '清理中...';
        resultDiv.style.display = 'none';

        try {
            // 发送消息给后台脚本
            const response = await chrome.runtime.sendMessage({ action: 'cleanDuplicates' });
            
            if (response.success) {
                showResult(response.message, 'success');
                if (response.duplicatesFound > 0) {
                    setTimeout(() => {
                        window.close();
                    }, 2000);
                }
            } else {
                showResult(response.message || '清理失败', 'error');
            }

            updateWindowStats();
        } catch (error) {
            showResult('发生错误：' + error.message, 'error');
        } finally {
            cleanBtn.disabled = false;
            cleanBtn.textContent = '立即清理重复窗口';
        }
    });

    // 更新窗口统计信息
    async function updateWindowStats() {
        try {
            const windows = await chrome.windows.getAll({ populate: true });
            let totalTabs = 0;
            
            windows.forEach(window => {
                totalTabs += window.tabs.length;
            });

            statsDiv.textContent = `当前有 ${windows.length} 个窗口，共 ${totalTabs} 个标签页`;
        } catch (error) {
            statsDiv.textContent = '无法获取窗口信息';
        }
    }

    // 显示结果消息
    function showResult(message, type) {
        resultDiv.textContent = message;
        resultDiv.className = 'result ' + type;
        resultDiv.style.display = 'block';
    }
});