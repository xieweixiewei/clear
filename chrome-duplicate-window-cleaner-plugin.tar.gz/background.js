// 后台脚本 - 处理重复窗口清理

// 导入核心清理逻辑（在实际环境中，这些函数已经在此文件中定义）

// 监听扩展安装事件
chrome.runtime.onInstalled.addListener(() => {
  console.log('重复窗口清理器已安装');
});

// 监听快捷键命令
chrome.commands.onCommand.addListener((command) => {
  if (command === 'clean-duplicates') {
    cleanDuplicateWindows();
  }
});

// 监听来自弹出窗口的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'cleanDuplicates') {
    cleanDuplicateWindows().then(result => {
      sendResponse(result);
    });
    return true; // 保持消息通道开放
  }
});

/**
 * 生成窗口的URL签名，用于识别重复窗口
 * @param {Array} tabs - 窗口中的标签页数组
 * @returns {string} - 排序后的URL签名
 */
function generateURLSignature(tabs) {
  if (!tabs || tabs.length === 0) {
    return '';
  }
  
  return tabs
    .map(tab => tab.url)
    .filter(url => url && !url.startsWith('chrome://'))
    .sort()
    .join('|');
}

/**
 * 识别重复窗口，返回需要关闭的窗口ID列表
 * @param {Array} windows - 所有窗口数组
 * @returns {Object} - 包含重复窗口信息的对象
 */
function identifyDuplicateWindows(windows) {
  const signatureMap = new Map(); // signature -> {windowId, createdTime}
  const duplicateWindows = [];
  
  for (const window of windows) {
    // 跳过最小化的窗口
    if (window.state === 'minimized') {
      continue;
    }
    
    const signature = generateURLSignature(window.tabs);
    
    // 跳过空签名（没有有效URL的窗口）
    if (!signature) {
      continue;
    }
    
    // 使用窗口ID作为创建时间的近似值（较小的ID通常表示较早创建）
    const createdTime = window.id;
    
    if (signatureMap.has(signature)) {
      const existing = signatureMap.get(signature);
      
      // 保留较早创建的窗口（ID较小的）
      if (createdTime < existing.createdTime) {
        // 当前窗口更早，关闭之前记录的窗口
        duplicateWindows.push({
          windowId: existing.windowId,
          signature: signature,
          reason: 'newer_duplicate'
        });
        signatureMap.set(signature, { windowId: window.id, createdTime });
      } else {
        // 当前窗口更晚，关闭当前窗口
        duplicateWindows.push({
          windowId: window.id,
          signature: signature,
          reason: 'newer_duplicate'
        });
      }
    } else {
      // 第一次看到这个签名，记录下来
      signatureMap.set(signature, { windowId: window.id, createdTime });
    }
  }
  
  return {
    duplicateWindows,
    uniqueSignatures: signatureMap.size,
    totalProcessed: windows.filter(w => w.state !== 'minimized').length
  };
}

/**
 * 安全关闭窗口列表
 * @param {Array} windowsToClose - 需要关闭的窗口信息数组
 * @returns {Object} - 关闭操作的结果
 */
async function safeCloseWindows(windowsToClose) {
  const results = {
    closed: 0,
    failed: 0,
    errors: []
  };
  
  for (const windowInfo of windowsToClose) {
    try {
      await chrome.windows.remove(windowInfo.windowId);
      results.closed++;
      console.log(`成功关闭窗口 ${windowInfo.windowId} (${windowInfo.reason})`);
    } catch (error) {
      results.failed++;
      const errorMsg = `无法关闭窗口 ${windowInfo.windowId}: ${error.message}`;
      results.errors.push(errorMsg);
      console.warn(errorMsg);
    }
  }
  
  return results;
}

/**
 * 清理重复窗口的主函数
 * @returns {Object} - 清理操作的详细结果
 */
async function cleanDuplicateWindows() {
  try {
    // 获取所有窗口及其标签页
    const windows = await chrome.windows.getAll({ populate: true });
    
    if (windows.length === 0) {
      return {
        success: true,
        duplicatesFound: 0,
        windowsClosed: 0,
        message: '没有找到任何窗口'
      };
    }
    
    // 识别重复窗口
    const duplicateInfo = identifyDuplicateWindows(windows);
    
    if (duplicateInfo.duplicateWindows.length === 0) {
      return {
        success: true,
        duplicatesFound: 0,
        windowsClosed: 0,
        message: '没有发现重复窗口',
        stats: {
          totalWindows: windows.length,
          processedWindows: duplicateInfo.totalProcessed,
          uniqueSignatures: duplicateInfo.uniqueSignatures
        }
      };
    }
    
    // 安全关闭重复窗口
    const closeResults = await safeCloseWindows(duplicateInfo.duplicateWindows);
    
    const result = {
      success: true,
      duplicatesFound: duplicateInfo.duplicateWindows.length,
      windowsClosed: closeResults.closed,
      message: closeResults.closed > 0 
        ? `已清理 ${closeResults.closed} 个重复窗口`
        : '发现重复窗口但清理失败',
      stats: {
        totalWindows: windows.length,
        processedWindows: duplicateInfo.totalProcessed,
        uniqueSignatures: duplicateInfo.uniqueSignatures,
        failedClosures: closeResults.failed
      }
    };
    
    // 如果有关闭失败的情况，添加错误信息
    if (closeResults.errors.length > 0) {
      result.errors = closeResults.errors;
      result.message += ` (${closeResults.failed} 个窗口关闭失败)`;
    }
    
    console.log('清理结果:', result);
    return result;
    
  } catch (error) {
    console.error('清理重复窗口时出错:', error);
    return {
      success: false,
      error: error.message,
      message: '清理过程中出现错误',
      duplicatesFound: 0,
      windowsClosed: 0
    };
  }
}

// 可选：定期自动清理（默认关闭）
// 可以通过存储设置来控制是否启用
chrome.storage.local.get(['autoCleanEnabled'], (result) => {
  if (result.autoCleanEnabled) {
    // 每30分钟检查一次
    setInterval(cleanDuplicateWindows, 30 * 60 * 1000);
  }
});